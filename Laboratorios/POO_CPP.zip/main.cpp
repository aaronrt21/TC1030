/*--------------------------------
* 
* Laboratorio: POO y C++
* Fecha: 15/Mayo/2020
* Autor: A01351621 Aarón Ramírez
*
--------------------------------*/

#include "isosceles.h"
#include <iostream>
using namespace std;

int main() {
  float a,b;
  a = 0;
  b = 0;
  Isosceles triangulo(a,b);
  cout << "Triangulo Isosceles" << "\n";
  cout << "Lado A = " << triangulo.getLadoA() << "\n";
  cout << "Lado B = " << triangulo.getLadoB() << "\n";
  cout << "Area = " << triangulo.calcArea(a,b) << "\n";
  cout << "Perimetro = " << triangulo.calcPerimetro(a,b) << "\n" << "\n";

  cout << "Lado A = ";
  cin >> a;
  cout << "\n";

  cout << "Lado B = ";
  cin >> b;
  cout << "\n";

  triangulo.setLadoA(a);
  triangulo.setLadoB(b);

  cout << "Triangulo Isosceles" << "\n";
  cout << "Lado A = " << triangulo.getLadoA() << "\n";
  cout << "Lado B = " << triangulo.getLadoB() << "\n";
  cout << "Area = " << triangulo.calcArea(a,b) << "\n";
  cout << "Perimetro = " << triangulo.calcPerimetro(a,b) << "\n" << "\n";

  return 0;
}