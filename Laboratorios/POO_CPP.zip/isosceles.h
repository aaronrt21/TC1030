/*--------------------------------
* 
* Laboratorio: POO y C++
* Fecha: 15/Mayo/2020
* Autor: A01351621 Aarón Ramírez
*
--------------------------------*/
#ifndef ISOSCELES_H
#define ISOSCELES_H
#include <iostream>
#include <math.h>
using namespace std;

class Isosceles {
  protected:

    float ladoa, ladob;

  public:

    Isosceles() {
      ladoa = 0;
      ladob = 0;
    }

    Isosceles(float la, float lb) {
      ladoa = la;
      ladob = lb;
    }

    float getLadoA() {
      return ladoa;
    }

    float getLadoB() {
      return ladob;
    }

    void setLadoA(float a) {
      ladoa = a;
    }

    void setLadoB(float b) {
      ladob = b;
    }

    float calcArea(float a, float b);

    float calcPerimetro(float a, float b);

};

float Isosceles::calcArea(float a, float b) {
  float area;
  area = (b*sqrt((a*a) - (b*b)/4))/2;
  //h = sqrt((a*a) - (b*b)/4);
  //area = (b*h)/2;
  return area;
}

float Isosceles::calcPerimetro(float a, float b) {
  float perimetro;
  perimetro = 2*a + b;
  return perimetro;
}

#endif